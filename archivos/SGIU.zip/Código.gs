function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('Plataforma SGIU - Gestión e Investigación')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// Incluye estilos, scripts y vistas de los módulos en la plantilla principal.
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// =========================================================================
// SIMULACIÓN DE ESTADO DE BASE DE DATOS (FA-005)
// =========================================================================
// 'true'  -> Prueba el FA-005 (Sin investigadores en la BD)
// 'false' -> Prueba el Flujo Básico Normal (Con datos)
var SIMULAR_SIN_INVESTIGADORES = false; 

function obtenerDatosReportes() {
  if (SIMULAR_SIN_INVESTIGADORES) {
    // Retorno FA-005: Sin investigadores registrados
    return {
      hayInvestigadores: false,
      kpis: {
        renacyt: 0,
        journals: 0,
        eventos: 0,
        cumplimiento: "0%"
      },
      investigadores: []
    };
  }

  // Retorno Flujo Básico Normal
  return {
    hayInvestigadores: true,
    kpis: {
      renacyt: 18,
      journals: 24,
      eventos: 32,
      cumplimiento: "92.5%"
    },
    investigadores: [
      {
        id: "1",
        nombre: "Dr. Carlos Alberto Mendoza",
        dni: "45892011",
        dedicacion: "Tiempo Completo",
        categoria: "Asociado",
        renacytNivel: "Nivel III",
        renacytCodigo: "P0023419",
        carrera: "Ingeniería de Sistemas",
        linea1: "Inteligencia Artificial y Ciencia de Datos",
        linea2: "Sistemas Distribuidos",
        publicaciones: [
          {
            titulo: "Deep Learning for Crop Disease Prediction in Andean Regions",
            evento: "IEEE International Conference on Data Mining (ICDM)",
            indexacion: "Scopus (WoS)",
            ranking: "Ranking: A1",
            hIndex: "14",
            estado: "Publicado"
          }
        ]
      }
    ]
  };
}
